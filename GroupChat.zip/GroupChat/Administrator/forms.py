from django import forms
from django.contrib.auth.models import User

  

class UserForm(forms.ModelForm):
    # specify the name of model to use
    class Meta:
        model = User
        fields = ('username','email','first_name','last_name','password')