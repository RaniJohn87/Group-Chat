from django.contrib import admin
from django.urls import path,include
from django.contrib.auth.decorators import login_required
from Administrator import views

urlpatterns = [
    path('add-user/', login_required(views.AddUser.as_view(),login_url = '/login'), name='add-user'),
    path('all-users/', login_required(views.ListOfUsers.as_view(),login_url = '/login'), name='list-of-users'),
    path('add-group/', login_required(views.AddGroup.as_view(),login_url = '/login'), name='list-of-users'),
    path('all-groups/', login_required(views.ListofGroups.as_view(),login_url = '/login'), name='list-of-groups'),
    path('grp-msg/<int:group_id>/', login_required(views.GroupMessagesListing.as_view(),login_url = '/login'), name='group-messages'),

    ############################## Edit ###############################
    path('edt-usr/<int:user_id>/', login_required(views.EditUser.as_view(),login_url = '/login'), name='edit-user'),
    path('edt-grp/<int:group_id>/', login_required(views.EditGroup.as_view(),login_url = '/login'), name='edit-group'),


]   