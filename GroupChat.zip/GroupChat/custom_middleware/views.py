from django.utils.deprecation import MiddlewareMixin


from django.contrib.auth.models import User

# class CheckAdmin(MiddlewareMixin):

# 	def process_view(self, request):
# 		print(request.user,"middleware")

from django.contrib.sessions.middleware import *



class SessionOverride(SessionMiddleware):

	def process_request(self, request):
		settings.SESSION_COOKIE_NAME = 'session_groupchat'
		
		session_key = request.COOKIES.get(settings.SESSION_COOKIE_NAME)
		request.session = self.SessionStore(session_key)
		is_admin = User.objects.filter(id=request.user.id,
								is_superuser = True,is_active = True,
								is_staff = True).exists()

		request.session['is_admin'] = is_admin