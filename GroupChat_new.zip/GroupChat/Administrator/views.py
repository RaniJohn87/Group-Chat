from django.shortcuts import render,redirect
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework import authentication

from rest_framework.authentication import  BasicAuthentication
from rest_framework.permissions import IsAuthenticated 

from rest_framework.renderers import TemplateHTMLRenderer
from django.http.response import JsonResponse

from django.contrib.auth import authenticate, login, logout
from Administrator.forms import *
from Administrator.models import *
from rest_framework.authentication import  SessionAuthentication,BasicAuthentication
from rest_framework.permissions import IsAuthenticated 
from django.http import HttpResponse, Http404, HttpResponseRedirect
# Create your views here.
class AddUser(APIView):
	permission_classes = [IsAuthenticated]
	authentication_classes = [SessionAuthentication]
	def get(self,request):

		context ={}
		context['form']= UserForm()
		return render(request,'add_user.html',context)
	def post(self,request):
		post_data = request.POST
		password = post_data.get('password')

		user_data_dict = {}
		for key,val in post_data.items():
			if str(key) == 'csrfmiddlewaretoken' or str(key) == 'submit':
				continue
			else:

				user_data_dict[key] = val
		user_data_dict['username'] = user_data_dict['username'].lower()

		user_data_dict.pop('password')
		user_obj = User.objects.create(**user_data_dict)

		userobj = User.objects.get(username = user_data_dict['username'])
		userobj.set_password(password)
		userobj.save()
		return redirect('/chat/all-users/')
		
class ListOfUsers(APIView):
	permission_classes = [IsAuthenticated]
	authentication_classes = [SessionAuthentication]
	renderer_classes = [TemplateHTMLRenderer]
	template_name = 'list_of_users.html'

	def get(self,request):

		user_objs = User.objects.all()

		return Response(locals())

class AuthenticateUser(APIView):
	
	renderer_classes = [TemplateHTMLRenderer]
	template_name = 'login.html'
	
	def get(self,request):
		title = "User Login"

		if request.user.is_authenticated:
			return redirect('/')


		return Response(locals())

	def post(self,request):

		post_data = request.POST
		username = post_data.get('username')
		password = post_data.get('password')
		
		
		user = authenticate(username=username, password=password)
		
		
		if user:
			if user.is_active:
				login(request, user)
				return redirect('/home')
		
		error = True
		return render(request,"login.html",locals())




class HomePage(APIView):
	permission_classes = [IsAuthenticated]
	authentication_classes = [SessionAuthentication]
	renderer_classes = [TemplateHTMLRenderer]
	template_name = 'home_page.html'
	
	def get(self,request):
		title = 'Home'
		if not request.user.is_authenticated:  
			return redirect('login/')
		return Response(locals())

def Logout(request):
	logout(request)
	return redirect('/login')

class AddGroup(APIView):
	permission_classes = [IsAuthenticated]
	authentication_classes = [SessionAuthentication]
	renderer_classes = [TemplateHTMLRenderer]
	template_name = 'add_group.html'

	def get(self,request):
		title = "Add Group"
		users = User.objects.exclude(id = request.user.id).filter(is_active = True)

		return Response(locals())
	def post(self,request):
		post_data = request.POST
		group_name = post_data.get('group_name')
		group_description = post_data.get("description")
		users = post_data.getlist('user')

		group_obj = GroupMasterTable.objects.create(group_name = group_name,
												created_by= request.user.id,
											group_description = group_description)

		users.append(int(request.user.id))
		for user_id in users:
			user_obj = User.objects.filter(id = user_id).first()
			group_obj.user_id.add(user_obj)	

		return redirect("/chat/all-groups")

class ListofGroups(APIView):
	permission_classes = [IsAuthenticated]
	authentication_classes = [SessionAuthentication]
	renderer_classes = [TemplateHTMLRenderer]
	template_name = 'all_groups.html'

	def get(self,request):
		title = "List of Groups"
		groups = GroupMasterTable.user_id.through.objects.filter(user_id = request.user.id).values_list('groupmastertable_id',flat = True)
		all_groups = GroupMasterTable.objects.filter(group_id__in = groups)
		return Response(locals())

class GroupMessagesListing(APIView):
	permission_classes = [IsAuthenticated]
	authentication_classes = [SessionAuthentication]
	renderer_classes = [TemplateHTMLRenderer]
	template_name = 'group_messages.html'

	def get(self, request,group_id):
		group_obj = GroupMasterTable.objects.filter(group_id = group_id).first()
		title = str(group_obj.group_name)

		all_messages = GroupMessages.objects.filter(group_id_id = group_id).order_by('created_at')
		return Response(locals())

	def post(self,request,group_id):
		post_data = request.POST
		message = post_data.get('message')
		message_obj = GroupMessages.objects.create(group_id_id = group_id,
									message_text = message,
									user_id_id = request.user.id)
		return redirect(f'/chat/grp-msg/{group_id}/')

class EditUser(APIView):
	permission_classes = [IsAuthenticated]
	authentication_classes = [SessionAuthentication]
	renderer_classes = [TemplateHTMLRenderer]
	template_name = 'edit_user.html'

	def get(self, request,user_id):
		title = 'Edit User'
		user_obj = User.objects.filter(id = user_id,is_active = True).first()
		if not user_obj:
			raise Http404()
		return Response(locals())

	def post(self,request,user_id):

		post_data = request.POST
		user_dict = {}

		for key,val in post_data.items():
			if str(key) == 'csrfmiddlewaretoken' or str(key) == 'submit':
				print(key)
				continue
			else:

				user_dict[key] = val

		user_obj = User.objects.filter(id = user_id).update(**user_dict)

		return redirect('/chat/all-users/')




class EditGroup(APIView):
	permission_classes = [IsAuthenticated]
	authentication_classes = [SessionAuthentication]
	renderer_classes = [TemplateHTMLRenderer]
	template_name = 'edit_group.html'
	
	def get(self,request,group_id):
		group_obj = GroupMasterTable.objects.filter(group_id = group_id).first()
		group_users = group_obj.user_id.all().values_list('id',flat = True)

		all_users = User.objects.filter(is_active = True).exclude(id__in = group_users).values()
		group_obj = GroupMasterTable.objects.filter(group_id= group_id)
		return Response(locals())

	def post(self,request,group_id):

		post_data = request.POST
		group_obj = GroupMasterTable.objects.filter(group_id = group_id).first()

		users = post_data.getlist('user')

		for user in users:
			user_obj = User.objects.filter(id = user).first()
			if user_obj:
				group_obj.user_id.add(user_obj)

		return redirect(f'/chat/grp-msg/{group_id}')