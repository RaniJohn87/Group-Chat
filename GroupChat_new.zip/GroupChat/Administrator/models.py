from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class GroupMasterTable(models.Model):
	user_id = models.ManyToManyField(User,related_name = 'group_users')
	group_id = models.BigAutoField(primary_key = True, unique = True)
	group_name = models.CharField(max_length = 500,null = True,blank = True)
	objects= models.Manager()
	group_description = models.TextField(null = True,blank = True)
	created_at = models.DateTimeField(auto_now_add=True,null=True,blank=True)
	created_by = models.BigIntegerField(null = True,blank = True)
	updated_at = models.DateTimeField(auto_now=True,null=True,blank=True)
	updated_by = models.BigIntegerField(null = True,blank = True)
	is_deleted = models.BooleanField(default = False)
	class Meta:
		db_table = 'group_master_table'

class GroupMessages(models.Model):
	group_id = models.ForeignKey(GroupMasterTable, to_field = 'group_id',on_delete = models.SET_NULL,blank = True,null = True)
	user_id = models.ForeignKey(User,on_delete = models.SET_NULL,blank = True,null = True)
	group_message_id = models.BigAutoField(primary_key = True, unique = True)
	objects= models.Manager()

	message_text = models.TextField(null = True,blank = True)
	like_count = models.BigIntegerField(null = True,blank = True)
	liked_by = models.ManyToManyField(User,related_name = 'liked_by_users')
	# liked_by (Many to Many To user Table)
	created_at = models.DateTimeField(auto_now_add=True,null=True,blank=True)
	class Meta:
		db_table = 'group_messages_table'